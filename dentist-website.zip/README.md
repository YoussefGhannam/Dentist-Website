# arrow-smile-dentist-website
This website is built for ArrowSmile dental clinic using HTML, CSS , JS for frontend and PHP & MySQL.
URL : http://arrowsmilerjwebtech.infinityfreeapp.com/

Featurs of the website:
1. Home section
2. About us with all facilities provided by detal clinic
3. our services section
4. treatment process section with informing images
5. clinets review section
6. appointment confirmation form with PHP & MySQL
7. awesome footer



